import{L as i}from"./index-yz7oKhjB.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
